# Skill: testing-mandatory.md
# Digunakan saat: menulis test baru, update test, atau test yang fail

---

## FILOSOFI TESTING OvnDB

```
Test bukan "pelengkap" — test adalah BUKTI bahwa kode bekerja.
Kode tanpa test yang pass = kode yang belum selesai.
Test yang skip/commented = bohong.
Test yang selalu pass karena assertionnya salah = lebih berbahaya dari tidak ada test.
```

---

## TAXONOMY TEST — Mana yang harus ditulis

### Unit Test (`test/unit/`)
**Kondisi:** Test logika murni, tidak butuh file system, tidak butuh DB open.

```typescript
// ✅ Cocok untuk unit test:
// - CRC32 calculation
// - ID generator format & uniqueness
// - Query filter matching (matchFilter())
// - Security validator (validateCollectionName(), etc.)
// - Schema validator logic
// - LRU cache eviction logic
// - WAL entry serialization/deserialization

// ❌ Tidak cocok untuk unit test:
// - insertOne (butuh disk)
// - find dengan index (butuh B+ Tree di disk)
// - transaction commit (butuh WAL di disk)
```

### Integration Test (`test/integration/`)
**Kondisi:** Test stack penuh, buka DB nyata di tmpdir, cleanup setelahnya.

```typescript
// ✅ Cocok untuk integration test:
// - insertOne + findOne end-to-end
// - Transaction commit/rollback
// - Index creation + query yang pakai index
// - WAL crash recovery (tulis → kill paksa → reopen)
// - Encryption round-trip (write encrypted → read back)
// - Persistence (write → close → reopen → verify)
// - Compaction + post-compact query

// ❌ Tidak cocok untuk integration test:
// - Pure logic tanpa I/O (gunakan unit test)
// - Performance/throughput test (gunakan benchmark)
```

### Security Test (`test/security/`)
**Kondisi:** Test setiap attack vector yang diidentifikasi di security audit.

```typescript
// Setiap security test HARUS:
// 1. Nama jelas → "menolak [attack] via [entry point]"
// 2. Membuktikan bahwa attack diblok (expect throw)
// 3. Membuktikan error message tidak bocorkan info sensitif
// 4. Tidak hanya test happy path
```

---

## TEMPLATE LENGKAP — Unit Test

```typescript
// ============================================================
//  OvnDB — Unit Tests: [NamaKomponen]
//  Cakupan:
//   1. [skenario 1 — deskripsi singkat]
//   2. [skenario 2]
//   3. [skenario 3]
// ============================================================

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

describe('[NamaKomponen]', async () => {

  // ── Import komponen yang ditest ──────────────────────────
  const { namaFungsi, NamaKelas } = await import('../../src/path/ke/file.js');

  // ── 1. Happy path ────────────────────────────────────────

  it('deskripsi hasil yang diharapkan dengan input valid', () => {
    // Arrange
    const input = 'contoh-input-valid';

    // Act
    const result = namaFungsi(input);

    // Assert
    assert.equal(result, 'expected-output');
  });

  // ── 2. Edge cases ────────────────────────────────────────

  it('menangani input kosong tanpa throw', () => {
    assert.doesNotThrow(() => namaFungsi(''));
  });

  it('mengembalikan nilai default untuk input undefined', () => {
    const result = namaFungsi(undefined as any);
    assert.equal(result, DEFAULT_VALUE);
  });

  // ── 3. Error cases ───────────────────────────────────────

  it('melempar Error dengan pesan yang benar untuk input invalid', () => {
    assert.throws(
      () => namaFungsi('input-yang-tidak-valid'),
      { message: /pesan error yang diharapkan/i }  // regex match, lebih robust dari exact string
    );
  });

  it('melempar Error bukan TypeError untuk input null', () => {
    assert.throws(
      () => namaFungsi(null as any),
      (err) => {
        assert.ok(err instanceof Error);
        assert.ok(err.message.includes('[OvnDB]'));  // semua error OvnDB prefix dengan [OvnDB]
        return true;
      }
    );
  });

  // ── 4. Batas limit ───────────────────────────────────────

  it('menerima input tepat di batas maksimum', () => {
    const atMax = 'x'.repeat(MAX_NILAI);
    assert.doesNotThrow(() => namaFungsi(atMax));
  });

  it('menolak input yang melampaui batas maksimum', () => {
    const overMax = 'x'.repeat(MAX_NILAI + 1);
    assert.throws(() => namaFungsi(overMax));
  });

});
```

---

## TEMPLATE LENGKAP — Integration Test

```typescript
// ============================================================
//  OvnDB — Integration Tests: [NamaFitur]
//  Cakupan:
//   1. [skenario end-to-end 1]
//   2. [skenario persistence]
//   3. [skenario error recovery]
// ============================================================

import { describe, it, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import os   from 'node:os';
import path from 'node:path';
import fs   from 'node:fs';
import fsp  from 'node:fs/promises';

// ── Helpers ──────────────────────────────────────────────────

function tmpDir(): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'ovndb-integ-'));
}

async function rmDir(p: string): Promise<void> {
  await fsp.rm(p, { recursive: true, force: true });
}

// ── Import ───────────────────────────────────────────────────

const { OvnDB } = await import('../../src/index.js');

// ── Test Suite ───────────────────────────────────────────────

describe('[NamaFitur] — integration', async () => {

  // Pola 1: Shared DB untuk test dalam satu suite
  describe('operasi dasar', async () => {
    let dir: string;
    let db: InstanceType<typeof OvnDB>;

    before(async () => {
      dir = tmpDir();
      db = await OvnDB.open(dir, { fileLock: false });
    });

    after(async () => {
      await db.close();
      await rmDir(dir);
    });

    it('insert dan find bekerja end-to-end', async () => {
      const col = await db.collection<{ name: string }>('items');
      const doc = await col.insertOne({ name: 'test' });

      assert.ok(doc._id);
      assert.equal(doc.name, 'test');

      const found = await col.findOne({ _id: doc._id });
      assert.deepEqual(found, doc);
    });
  });

  // Pola 2: Isolated DB per test (untuk test yang butuh state bersih)
  describe('persistence setelah reopen', async () => {
    it('data tidak hilang setelah close dan reopen', async () => {
      const dir = tmpDir();
      try {
        // Write
        const db1 = await OvnDB.open(dir, { fileLock: false });
        const col1 = await db1.collection<{ val: number }>('data');
        await col1.insertOne({ _id: 'x1', val: 42 });
        await db1.close();

        // Reopen dan verify
        const db2 = await OvnDB.open(dir, { fileLock: false });
        const col2 = await db2.collection<{ val: number }>('data');
        const doc = await col2.findOne({ _id: 'x1' });

        assert.ok(doc, 'dokumen harus ada setelah reopen');
        assert.equal(doc.val, 42);

        await db2.close();
      } finally {
        await rmDir(dir);
      }
    });
  });

  // Pola 3: Test error recovery
  describe('error handling', async () => {
    it('melempar error deskriptif untuk operasi invalid', async () => {
      const dir = tmpDir();
      try {
        const db = await OvnDB.open(dir, { fileLock: false });
        const col = await db.collection<{}>('test');

        await assert.rejects(
          async () => col.insertOne({ _id: 'a'.repeat(200) }),  // _id terlalu panjang
          { message: /\[OvnDB\]/ }
        );

        await db.close();
      } finally {
        await rmDir(dir);
      }
    });
  });
});
```

---

## TEMPLATE LENGKAP — Security Test

```typescript
// ============================================================
//  OvnDB — Security Tests: [NamaKomponen / Attack Vector]
//  Setiap test membuktikan satu attack vector diblokir.
// ============================================================

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import os   from 'node:os';
import path from 'node:path';
import fs   from 'node:fs';
import fsp  from 'node:fs/promises';

const { OvnDB } = await import('../../src/index.js');
const { validateCollectionName, isDangerousKey } = await import('../../src/utils/security.js');

describe('security — [NamaKomponen]', async () => {

  // Format nama test: [attack type] via [entry point] diblokir
  it('path traversal via collection name diblokir', () => {
    assert.throws(
      () => validateCollectionName('../secret'),
      { message: /\[OvnDB\]/ }
    );
  });

  it('error message tidak membocorkan nilai _id', async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sec-'));
    try {
      const db = await OvnDB.open(dir, { fileLock: false });
      const col = await db.collection<{}>('test');
      await col.insertOne({ _id: 'sensitif-12345' });

      try {
        await col.insertOne({ _id: 'sensitif-12345' });  // duplikat
        assert.fail('harus throw');
      } catch (err) {
        assert.ok(err instanceof Error);
        // Error TIDAK BOLEH berisi nilai _id
        assert.ok(!err.message.includes('sensitif-12345'),
          `Error message membocorkan _id: "${err.message}"`
        );
      }

      await db.close();
    } finally {
      await fsp.rm(dir, { recursive: true, force: true });
    }
  });

});
```

---

## ATURAN ASSERTION

### Gunakan `assert/strict` selalu:
```typescript
import assert from 'node:assert/strict';

// ✅ Strict equality
assert.equal(a, b);         // a === b
assert.deepEqual(a, b);     // deep ===
assert.notEqual(a, b);      // a !== b

// ✅ Check throw dengan match
assert.throws(fn, { message: /regex/ });
assert.throws(fn, { name: 'TypeError' });

// ✅ Check async throw
await assert.rejects(asyncFn, { message: /regex/ });

// ✅ Tidak throw
assert.doesNotThrow(fn);
await assert.doesNotReject(asyncFn);

// ✅ Truthiness
assert.ok(value, 'pesan jika false');
```

### Jangan:
```typescript
// ❌ Loose equality
assert(a == b);  // pakai assert.equal

// ❌ Assert tanpa pesan untuk boolean check
assert.ok(result);  // → assert.ok(result, 'result harus truthy: ...')

// ❌ try-catch untuk assert (hiding failure)
try {
  assert.equal(a, b);
} catch (e) {
  // ignored
}
```

---

## MENJALANKAN TEST — Command Reference

```bash
# ── Single file (development) ────────────────────────────────
OVNDB_LOG=silent node --import tsx/esm --test test/unit/utils.test.ts
OVNDB_LOG=silent node --import tsx/esm --test test/integration/collection.test.ts

# ── Per suite ────────────────────────────────────────────────
npm run test:unit         # unit saja
npm run test:integration  # integration saja
npm run test:security     # security saja

# ── Full (CI gate — wajib pass sebelum declare done) ─────────
npm test

# ── Watch mode (development aktif) ──────────────────────────
npm run test:watch  # jika tersedia, atau:
node --import tsx/esm --test --watch test/unit/nama.test.ts

# ── Dengan verbose output ────────────────────────────────────
OVNDB_LOG=debug node --import tsx/esm --test test/unit/nama.test.ts

# ── Check output exit code ───────────────────────────────────
npm test; echo "EXIT CODE: $?"
# EXIT CODE: 0 = semua pass
# EXIT CODE: 1 = ada yang fail
```

---

## INTERPRETASI OUTPUT TEST

```
✓ nama test (Xms)     → PASS
✗ nama test           → FAIL — BACA ERROR DI BAWAHNYA
- nama test           → SKIPPED — WAJIB ada alasan, kalau tidak ada lapor ke user

# Output summary di akhir:
pass 42               → jumlah yang pass
fail 0                → HARUS 0 sebelum declare done
skip 0                → HARUS 0 atau ada justifikasi
```

### Jika ada `fail N`:
1. Scroll up ke test yang fail
2. Baca `AssertionError: ... Expected values ...`
3. Baca stack trace → baris pertama di `src/` adalah titik awal debug
4. Gunakan `debug-fix.md` untuk prosedur fix

### Jika ada test yang intermittently fail (flaky):
- Jangan re-run sampai pass → ini adalah race condition atau dependency antar test
- Tandai dan investigasi dengan `debug-fix.md` kategori D (concurrency)
