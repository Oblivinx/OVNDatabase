# Skill: debug-fix.md
# Digunakan saat: ada bug, test fail, runtime error, atau perilaku tidak sesuai

---

## PRINSIP DASAR DEBUGGING OvnDB

```
1. BACA ERROR LENGKAP — jangan tebak sebelum baca stack trace sampai habis
2. REPRODUKSI DULU — pastikan bisa reproduce secara konsisten sebelum fix
3. UNDERSTAND ROOT CAUSE — jangan patch symptom, fix penyebab sebenarnya
4. FIX MINIMAL — ubah sesedikit mungkin untuk fix bug
5. VERIFY TIDAK MERUSAK LAIN — jalankan full test suite setelah fix
```

---

## LANGKAH 1 — Triage (Klasifikasi Bug)

Sebelum menyentuh kode, tentukan kategori bug:

```
KATEGORI A — Logic Bug (output salah)
  Gejala: test assert failed, nilai tidak sesuai ekspektasi
  Langkah: baca test yang fail → trace data flow → find divergence point

KATEGORI B — Crash / Exception
  Gejala: process exit, uncaught exception, unhandled promise rejection
  Langkah: baca stack trace SELURUHNYA → identifikasi baris eksak → trace call chain

KATEGORI C — Memory / Resource
  Gejala: OOM, process terlambat, memory naik terus
  Langkah: tambah log di titik alokasi → monitor ukuran buffer/cache

KATEGORI D — Concurrency / Race Condition
  Gejala: test kadang pass kadang fail (flaky), data corrupt
  Langkah: cari shared mutable state → cari missing await → cari missing lock

KATEGORI E — Data Corruption
  Gejala: data berubah sendiri, CRC mismatch, invalid JSON saat dibaca
  Langkah: cek WAL replay → cek CRC → cek encoding/decoding consistency
```

---

## LANGKAH 2 — Baca Error Secara Sistematis

### 2.1 Untuk test failure:
```bash
# Jalankan HANYA test yang fail, dengan output penuh
node --import tsx/esm --test test/path/ke/test.ts 2>&1

# Baca output dari atas:
# - Nama test yang fail
# - Expected vs Actual
# - Stack trace: BACA SAMPAI BARIS PERTAMA di src/ (bukan di node_modules)
```

### 2.2 Checklist membaca stack trace:
```
□ Baris pertama: jenis error (TypeError, AssertionError, Error, dll)
□ Baris kedua: pesan error — baca SELURUH pesan, jangan potong
□ Trace frames: cari frame pertama yang ada di src/ → ini titik awal investigasi
□ Jika ada "at async" — artinya error terjadi dalam Promise chain
□ Jika ada "at Object.<anonymous>" — artinya di test file sendiri
```

### 2.3 Template logging debug (tambah sementara, hapus setelah fix):
```typescript
// Tambah log ini sementara untuk trace:
import { makeLogger } from '../utils/logger.js';
const log = makeLogger('debug-[namafile]');

// Di dalam fungsi yang dicurigai:
log.debug('DEBUG checkpoint', {
  input: JSON.stringify(input).slice(0, 200),  // batasi 200 char
  state: { /* state relevan */ },
});

// WAJIB HAPUS sebelum menyatakan fix selesai
```

---

## LANGKAH 3 — Isolasi Bug

### 3.1 Buat reproduksi minimal:
```typescript
// Buat file sementara: /tmp/repro.ts
import { OvnDB } from './src/index.js';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'repro-'));

try {
  const db = await OvnDB.open(dir, { fileLock: false });
  const col = await db.collection('test');

  // MINIMUM REPRODUKSI BUG
  // ...

  await db.close();
} finally {
  fs.rmSync(dir, { recursive: true, force: true });
}
```

```bash
# Jalankan reproduksi
OVNDB_LOG=debug node --import tsx/esm /tmp/repro.ts 2>&1
```

### 3.2 Binary search lokasi bug:
Jika stack trace tidak jelas, lakukan binary search:
```
1. Tambah log di tengah fungsi yang dicurigai
2. Jalankan → apakah log muncul?
   - Ya → bug ada di paruh KEDUA fungsi → pindah log ke 3/4
   - Tidak → bug ada di paruh PERTAMA fungsi → pindah log ke 1/4
3. Ulangi sampai lokasi tepat ditemukan (max 5-6 iterasi)
```

---

## LANGKAH 4 — Analisis Root Cause

Sebelum fix, jawab ini:

```
WHAT: Apa yang seharusnya terjadi vs apa yang terjadi?
WHERE: Baris/fungsi eksak di mana divergensi terjadi?
WHY: Kenapa kode berperilaku seperti ini?
       (salah asumsi? race condition? off-by-one? wrong type? missing await?)
SCOPE: Apakah bug ini hanya di satu tempat, atau ada tempat lain yang sama pattern-nya?
```

### Pattern bug yang umum di OvnDB:

```typescript
// BUG 1: Missing await pada async operation
async function namaFunc() {
  this.wal.append(op, key, data);  // ❌ tidak await — operasi mungkin belum selesai
  await this.wal.append(op, key, data);  // ✅
}

// BUG 2: BigInt comparison dengan number
if (txId === 0) { ... }          // ❌ 0n !== 0
if (txId === 0n) { ... }         // ✅

// BUG 3: Buffer offset off-by-one
const status = buf.readUInt8(0);   // offset 0
const txId = buf.readBigUInt64LE(1);  // offset 1 (setelah 1 byte status)
const dataLen = buf.readUInt32LE(9);  // offset 9 (setelah 1 + 8 = 9 bytes)
// Hitung dengan teliti: REC_STATUS_SIZE + REC_TXID_SIZE + ...

// BUG 4: Path separator di Windows vs Unix
path.join(dir, name)   // ✅ gunakan path.join, bukan string concat
dir + '/' + name       // ❌

// BUG 5: CRC dihitung dari buffer yang salah
const crc = crc32(buf.slice(0, dataEnd));  // harus cover semua field kecuali CRC itu sendiri

// BUG 6: File descriptor leak
const fd = fs.openSync(file, 'r');
// ... lupa fs.closeSync(fd) saat error
// ✅ pakai try/finally:
try { ... } finally { if (fd !== null) fs.closeSync(fd); }
```

---

## LANGKAH 5 — Implementasi Fix

### 5.1 Aturan fix:
```
✅ Fix HARUS sesedikit mungkin — ubah minimum baris
✅ Fix TIDAK BOLEH mengubah public API tanpa persetujuan user
✅ Fix HARUS disertai komentar: kenapa perubahan ini diperlukan
✅ Jika fix melibatkan logika kompleks, tambahkan komentar BEFORE/AFTER
```

### 5.2 Template komentar fix:
```typescript
// FIX [tanggal]: [deskripsi bug yang diperbaiki]
// SEBELUMNYA: [code lama atau penjelasan perilaku lama]
// SEKARANG: [penjelasan perilaku baru]
// ROOT CAUSE: [kenapa bug ini terjadi]
const correctedValue = ...; // ← ini yang difix
```

### 5.3 Jangan:
```typescript
// ❌ Jangan hapus test yang fail — fix kodenya, bukan test-nya
// (kecuali test memang salah, dan harus dijelaskan kenapa)

// ❌ Jangan tambahkan try-catch untuk suppress error
try {
  await problematicOperation();
} catch (e) {
  // suppress — ini adalah patchwork, bukan fix
}

// ❌ Jangan ubah behavior test dengan mengubah data test
// agar hasilnya cocok — ini hiding bug

// ✅ Fix logika yang salah, bukan test atau data
```

---

## LANGKAH 6 — Verifikasi Fix

### 6.1 Urutan verifikasi wajib:
```bash
# 1. Test yang tadinya fail — HARUS pass sekarang
node --import tsx/esm --test test/[path/ke/test-yang-fail].ts
echo "EXIT: $?"  # HARUS 0

# 2. TypeScript masih clean
npx tsc --noEmit
echo "EXIT: $?"  # HARUS 0

# 3. Unit test tidak rusak
npm run test:unit
echo "EXIT: $?"  # HARUS 0

# 4. Integration test tidak rusak
npm run test:integration
echo "EXIT: $?"  # HARUS 0

# 5. Security test tidak rusak
npm run test:security
echo "EXIT: $?"  # HARUS 0

# 6. Full suite
npm test
echo "EXIT: $?"  # HARUS 0
```

### 6.2 Verifikasi regression:
Jika fix menyentuh storage layer atau WAL, WAJIB jalankan ini tambahan:
```bash
# Pastikan data yang sudah ada tidak corrupt setelah fix
npx tsx examples/basic-usage.ts
npx tsx examples/complex-crud.ts

# Jika ada data penting untuk diverifikasi persistence:
# buat script sementara yang:
# 1. Insert data
# 2. Close DB
# 3. Re-open DB
# 4. Verify data masih ada dan benar
```

### 6.3 Bersih-bersih setelah fix:
```bash
# Pastikan tidak ada debug log tertinggal
grep -rn "console\.log\|console\.error" src/ --include="*.ts"
grep -rn "log\.debug.*DEBUG\|DEBUG checkpoint" src/ --include="*.ts"

# Pastikan tidak ada file temp tertinggal
ls /tmp/repro*.ts 2>/dev/null && echo "⚠️ Ada file repro sementara, hapus!"
```

---

## LANGKAH 7 — Report ke User

Format laporan setelah fix:

```
✅ BUG FIXED

ROOT CAUSE:
[Penjelasan teknis — 2-4 kalimat]

FILE YANG DIUBAH:
- src/xxx.ts baris N: [deskripsi perubahan]
- src/yyy.ts baris M: [deskripsi perubahan]

TEST RESULT:
[Paste output npm test — minimal 10 baris terakhir]

APAKAH ADA RISIKO REGRESSION?
[Ya/Tidak — penjelasan singkat]

CATATAN TAMBAHAN:
[Jika ada pola bug serupa di tempat lain yang perlu diperiksa user]
```
