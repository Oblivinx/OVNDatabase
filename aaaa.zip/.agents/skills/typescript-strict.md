# Skill: typescript-strict.md
# Digunakan saat: refactor TypeScript, ubah types, atau ada TypeScript error

---

## KONFIGURASI COMPILER — Pahami implikasinya

OvnDB menggunakan konfigurasi TypeScript yang ketat. Setiap flag punya implikasi:

```jsonc
{
  "strict": true,                        // Aktifkan semua strict checks
  "noUncheckedIndexedAccess": true,      // array[i] bisa undefined — WAJIB check
  "noImplicitOverride": true,            // override method WAJIB keyword 'override'
  "moduleResolution": "NodeNext",        // import WAJIB pakai .js extension
  "target": "ES2022"                     // BigInt native, await top-level OK
}
```

### Implikasi `noUncheckedIndexedAccess`:
```typescript
// ❌ Error: Object is possibly 'undefined'
const arr = [1, 2, 3];
const first = arr[0];
first.toString();  // TypeScript complain karena arr[0] bisa undefined

// ✅ Cara 1: non-null assertion (hanya jika YAKIN tidak undefined)
const first = arr[0]!;

// ✅ Cara 2: nullish check
const first = arr[0];
if (first !== undefined) first.toString();

// ✅ Cara 3: at() dengan default
const first = arr.at(0) ?? defaultValue;
```

### Implikasi `moduleResolution: NodeNext`:
```typescript
// ❌ Selalu error
import { foo } from './utils/bar';
import { foo } from './utils/bar.ts';

// ✅ Selalu benar (pakai .js bahkan untuk .ts file)
import { foo } from './utils/bar.js';
import type { MyType } from './types/index.js';
```

---

## POLA TYPES YANG DIPAKAI DI OVNDB

### OvnDocument — dokumen yang disimpan
```typescript
// Dari types/index.ts — semua dokumen HARUS extend ini
export interface OvnDocument {
  _id: string;
  [key: string]: unknown;  // allow arbitrary fields
}

// Cara paling aman menggunakan generics
const col = await db.collection<User>('users');
// TypeScript tahu bahwa col.insertOne() butuh User, bukan arbitrary object
```

### QueryFilter — query user
```typescript
// Dari types/index.ts
export type QueryFilter = Record<string, unknown>;

// Saat mengimplementasikan logic yang terima filter:
function processFilter(filter: QueryFilter): void {
  // Selalu validate dulu
  validateQueryFilter(filter);

  for (const [key, value] of Object.entries(filter)) {
    // key adalah string, value adalah unknown
    // JANGAN assume tipe value — check eksplisit
    if (typeof value === 'object' && value !== null) {
      const ops = value as Record<string, unknown>;
      // sekarang bisa akses ops.$eq dll
    }
  }
}
```

### Buffer operations — sangat umum di storage layer
```typescript
// Alokasi
const buf = Buffer.allocUnsafe(size);    // tidak di-initialize → lebih cepat tapi HARUS di-fill
const buf = Buffer.alloc(size);          // di-initialize ke 0 → lebih lambat tapi aman

// Read/Write dengan offset tracking
let offset = 0;
buf.writeUInt8(status, offset);         offset += 1;    // REC_STATUS_SIZE
buf.writeBigUInt64LE(txId, offset);     offset += 8;    // REC_TXID_SIZE
buf.writeUInt32LE(dataLen, offset);     offset += 4;    // REC_DATALEN_SIZE
data.copy(buf, offset);                  offset += data.length;
writeCrc(buf, offset);                   offset += 4;   // REC_CRC_SIZE

// Verifikasi offset akhir = panjang buffer
if (offset !== buf.length) {
  throw new Error(`[OvnDB] Buffer size mismatch: expected ${buf.length}, wrote ${offset}`);
}
```

### BigInt — untuk txId dan record count
```typescript
// OvnDB menggunakan BigInt untuk txId dan record pointer

// ✅ Operasi BigInt yang benar
const txId: bigint = 0n;
const nextTxId = txId + 1n;               // arithmetic pakai n suffix
const isValid = txId > 0n;                // comparison pakai n suffix
const txIdNum = Number(txId);             // konversi ke number HANYA jika ≤ Number.MAX_SAFE_INTEGER

// ❌ Penyebab bug umum
if (txId === 0) { ... }                   // 0n !== 0 → selalu false
if (txId > Number.MAX_SAFE_INTEGER) { }   // tidak jalan karena type mismatch

// ✅ Check safe integer sebelum konversi
if (txId > BigInt(Number.MAX_SAFE_INTEGER)) {
  throw new Error('[OvnDB] txId melebihi safe integer range');
}
const num = Number(txId);  // aman sekarang
```

---

## ERROR HANDLING — Pola yang Konsisten

### Error dari OvnDB selalu prefix `[OvnDB]`:
```typescript
// ✅ Format standar
throw new Error('[OvnDB] NamaKomponen: deskripsi masalah yang jelas');

// ✅ Dengan context tapi tanpa data sensitif
throw new Error(`[OvnDB] WAL: entry key terlalu panjang (max ${WAL_KEY_MAX_LEN})`);

// ❌ Tanpa prefix
throw new Error('duplicate key');

// ❌ Dengan data sensitif
throw new Error(`[OvnDB] Record not found: "${id}"`);
```

### Error classes untuk kasus spesifik:
```typescript
// Sudah ada di codebase — gunakan yang sudah ada
import { WriteConflictError } from '../transaction/mvcc.js';
import { RollbackFailedError } from '../transaction/transaction.js';

// Membuat error class baru (hanya jika perlu catch spesifik):
export class ValidationError extends Error {
  constructor(
    message: string,
    public readonly field?: string
  ) {
    super(`[OvnDB] Validation: ${message}`);
    this.name = 'ValidationError';
  }
}
```

### Async error handling:
```typescript
// ✅ Pola yang benar untuk async cleanup
async function openWithCleanup(path: string): Promise<Resource> {
  let fd: number | null = null;
  try {
    fd = fs.openSync(path, 'r+');
    // ... gunakan fd
    return resource;
  } catch (err) {
    if (fd !== null) fs.closeSync(fd);
    // Re-throw dengan context
    throw new Error(`[OvnDB] Gagal membuka ${basename(path)}: ${(err as Error).message}`);
  }
}

// ✅ Promise chain dengan cleanup
async function withTransaction<T>(fn: () => Promise<T>): Promise<T> {
  const tx = this.beginTransaction();
  try {
    const result = await fn();
    await tx.commit();
    return result;
  } catch (err) {
    await tx.rollback().catch(() => {}); // rollback error tidak override original
    throw err;
  }
}
```

---

## TYPE GUARDS — Kapan dan Bagaimana

```typescript
// Untuk unknown values dari disk/user:
function isRecord(val: unknown): val is Record<string, unknown> {
  return typeof val === 'object' && val !== null && !Array.isArray(val);
}

function isOvnDocument(val: unknown): val is OvnDocument {
  return isRecord(val) && typeof (val as OvnDocument)._id === 'string';
}

// Gunakan type guard sebelum akses property:
const parsed: unknown = JSON.parse(buf.toString());
if (!isOvnDocument(parsed)) {
  throw new Error('[OvnDB] Data di disk bukan OvnDocument yang valid');
}
// Sekarang TypeScript tahu parsed._id adalah string
```

---

## READONLY DAN IMMUTABILITY

```typescript
// ✅ Private state yang tidak boleh diubah dari luar
private readonly dirPath: string;
private readonly colName: string;

// ✅ Readonly object di public interface
readonly stats: Readonly<OvnStats>;

// ✅ ReadonlyArray untuk array yang tidak boleh dimutasi
readonly segments: ReadonlyArray<SegmentMeta>;

// ✅ Freeze untuk konstanta object
const EMPTY_FILTER = Object.freeze({} as QueryFilter);
```

---

## POLA ASYNC YANG BENAR

```typescript
// ✅ Batch async dengan error tracking
async function processAll(items: string[]): Promise<void> {
  const errors: Error[] = [];

  await Promise.all(items.map(async (item) => {
    try {
      await processOne(item);
    } catch (err) {
      errors.push(err as Error);
    }
  }));

  if (errors.length > 0) {
    throw new Error(`[OvnDB] ${errors.length} item gagal: ${errors[0]?.message}`);
  }
}

// ✅ Sequential dengan early exit
async function processSequential(items: string[]): Promise<void> {
  for (const item of items) {
    await processOne(item);  // throw langsung jika ada error → early exit
  }
}

// ❌ Fire and forget tanpa error handling
items.forEach(item => processOne(item));  // error di-swallow

// ❌ Promise.all tanpa error handling
await Promise.all(items.map(item => processOne(item)));
// → satu gagal = semua gagal, tapi yang lain sudah jalan (inconsistent state)
```

---

## MENGATASI TYPESCRIPT ERROR UMUM

### Error: "Object is possibly undefined" (noUncheckedIndexedAccess)
```typescript
// Problem:
const entry = this.entries[index];
entry.process();  // ❌ entry might be undefined

// Fix options:
const entry = this.entries[index];
if (!entry) throw new Error(`[OvnDB] entry[${index}] tidak ada`);
entry.process();  // ✅

// atau dengan non-null assertion (hanya jika logika sudah menjamin tidak undefined)
const entry = this.entries[index]!;  // ✅ dengan comment kenapa tidak mungkin undefined
```

### Error: "Property X does not exist on type 'unknown'"
```typescript
// Problem:
const data: unknown = JSON.parse(str);
data.name;  // ❌

// Fix:
const data = JSON.parse(str) as Record<string, unknown>;
const name = typeof data.name === 'string' ? data.name : null;  // ✅ type-safe
```

### Error: "Argument of type 'bigint' is not assignable to type 'number'"
```typescript
// Problem:
const size: number = this.tree.size;  // ❌ tree.size adalah bigint

// Fix:
const size = Number(this.tree.size);  // ✅ explicit conversion
// TAPI: check dulu apakah aman
if (this.tree.size > BigInt(Number.MAX_SAFE_INTEGER)) {
  throw new Error('[OvnDB] ukuran tree melebihi safe integer');
}
```

### Error: "Type '...' is not assignable to parameter of type 'never'"
```typescript
// Problem: exhaustive check di switch tidak dihandle
switch (op.kind) {
  case 'insert': ...;
  case 'update': ...;
  // lupa 'delete' dan 'upsert'
  default:
    const _exhaustive: never = op;  // ❌ error jika ada case yang belum dihandle
}

// Fix: tambahkan semua case yang missing
switch (op.kind) {
  case 'insert': ...; break;
  case 'update': ...; break;
  case 'delete': ...; break;
  case 'upsert': ...; break;
  default: {
    const _exhaustive: never = op;  // ✅ TypeScript memverifikasi semua case di-cover
    throw new Error(`[OvnDB] Unknown op kind: ${(_exhaustive as any).kind}`);
  }
}
```

---

## COMMAND VERIFIKASI TYPESCRIPT

```bash
# Check tanpa emit (cepat, hanya type check)
npx tsc --noEmit
echo "TypeScript errors: $?"  # HARUS 0

# Check dengan detail error yang lebih informatif
npx tsc --noEmit --pretty 2>&1 | head -50

# Build penuh (untuk verifikasi final)
npm run build
echo "Build status: $?"  # HARUS 0

# Check file spesifik (lebih cepat untuk investigasi)
npx tsc --noEmit --strict src/core/storage/storage-engine.ts 2>&1
```
