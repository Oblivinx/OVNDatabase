# Skill: new-feature.md
# Digunakan saat: implementasi fitur baru yang belum ada di codebase

---

## LANGKAH 1 — Analisis & Perencanaan (WAJIB, tidak boleh skip)

### 1.1 Baca kontrak existing
Sebelum menulis satu baris pun, baca file-file ini secara berurutan:

```bash
# Baca types — ini adalah kontrak semua komponen
cat src/types/index.ts
cat src/types/constants.ts

# Baca entry point publik
cat src/index.ts   # (atau src/collection/collection.ts untuk fitur collection)

# Cari pola serupa yang sudah ada
grep -rn "NAMA_KONSEP_SERUPA" src/ --include="*.ts"
```

### 1.2 Tentukan posisi dalam arsitektur
Sebelum mulai, jawab pertanyaan ini secara eksplisit (tulis dalam respons ke user):

```
LAYER MANA yang akan diubah?
□ API layer     (src/collection/ atau src/index.ts)
□ Query layer   (src/core/query/)
□ Storage layer (src/core/storage/, src/core/wal/, src/core/index/)
□ Utils layer   (src/utils/)
□ Types layer   (src/types/)
□ Lintas layer  → sebutkan semua layer

FILE MANA yang akan dibuat/diubah?
→ Daftarkan semua file secara eksplisit sebelum mulai

ADA BREAKING CHANGE ke public API?
□ Ya  → LAPOR ke user SEBELUM implementasi
□ Tidak
```

### 1.3 Desain interface dulu
Tulis interface/type yang akan dipakai SEBELUM implementasi:

```typescript
// Contoh: desain dulu di types/index.ts
export interface BloomFilterOptions {
  /** Target false positive rate (0.01 = 1%). Default: 0.01 */
  falsePositiveRate?: number;
  /** Estimasi jumlah elemen yang akan dimasukkan */
  expectedElements:  number;
}

export interface IBloomFilter {
  add(key: string): void;
  mightContain(key: string): boolean;
  readonly bitCount: number;
  readonly hashCount: number;
  serialize(): Buffer;
  deserialize(buf: Buffer): void;
}
```

Tunjukkan desain interface ke user dan tunggu persetujuan untuk fitur besar.

---

## LANGKAH 2 — Implementasi (urutan wajib)

### 2.1 Urutan penulisan file
Selalu tulis dalam urutan dependency — dari bawah ke atas:

```
1. types/constants.ts  ← tambah konstanta baru
2. types/index.ts      ← tambah type/interface baru
3. src/utils/security.ts ← tambah validasi baru (jika ada input user)
4. src/core/.../       ← implementasi core logic
5. src/collection/     ← expose ke public API (jika perlu)
6. src/index.ts        ← export (jika bagian dari public API)
7. test/unit/          ← unit test (murni logic, no disk)
8. test/integration/   ← integration test (full stack)
```

**JANGAN** loncat ke nomor 5 sebelum nomor 4 selesai dan compile.

### 2.2 Setelah setiap file selesai — WAJIB:
```bash
npx tsc --noEmit 2>&1
# Jika ada error → FIX SEKARANG, jangan lanjut ke file berikutnya
```

### 2.3 Template file implementasi baru:
```typescript
// ============================================================
//  OvnDB v[VERSI] — [NamaKomponen]
//
//  [Penjelasan tanggung jawab komponen — 2-4 kalimat]
//
//  DESAIN:
//  - [Keputusan arsitektur 1 + alasannya]
//  - [Keputusan arsitektur 2 + alasannya]
//
//  REFERENSI:
//  - [Paper/artikel jika implementasi based on research]
// ============================================================

import { makeLogger } from '../utils/logger.js';

const log = makeLogger('[nama-komponen]');

export class NamaKelas {
  // Semua property dengan visibility modifier yang tepat
  private readonly _config: KonfigType;

  constructor(config: KonfigType) {
    // Validasi input di constructor — fail fast
    if (!config.field) throw new Error('[OvnDB] NamaKelas: field wajib diisi');
    this._config = config;
    log.debug('NamaKelas initialized', { config });
  }

  /**
   * Deskripsi fungsi — apa yang dilakukan, bukan bagaimana.
   * @param param - Penjelasan parameter
   * @returns Penjelasan return value
   * @throws {Error} Kondisi yang menyebabkan error
   */
  async namaFungsi(param: TipeParam): Promise<TipeReturn> {
    // Validasi input
    // Core logic
    // Return
  }
}
```

---

## LANGKAH 3 — Menulis Test (WAJIB, bukan opsional)

### 3.1 Coverage minimum yang wajib dipenuhi:

Untuk setiap fitur baru, test WAJIB mencakup:

```
□ Happy path — input valid, output sesuai ekspektasi
□ Edge case: input kosong / null / undefined
□ Edge case: input di batas limit (tepat di MAX, tepat di MIN)
□ Edge case: input melebihi limit (MAX + 1)
□ Error case: input yang tidak valid harus throw dengan pesan yang benar
□ Persistence: jika data disimpan ke disk, close DB, re-open, verifikasi data masih ada
□ Concurrent: jika ada state mutable, test concurrent access (minimal 2 caller)
```

### 3.2 Contoh coverage check:
```typescript
describe('BloomFilter', async () => {
  // ✅ Happy path
  it('mendeteksi key yang sudah ditambahkan', () => { ... });

  // ✅ Edge case input kosong
  it('menangani key string kosong tanpa throw', () => { ... });

  // ✅ Batas limit — tepat di MAX
  it('berfungsi dengan expectedElements tepat di MAX_BLOOM_ELEMENTS', () => { ... });

  // ✅ Melebihi limit
  it('melempar error jika expectedElements melebihi MAX_BLOOM_ELEMENTS', () => { ... });

  // ✅ False positive rate kontrol
  it('false positive rate tidak melebihi target dalam 10.000 probe', () => { ... });

  // ✅ Serialization round-trip
  it('serialize + deserialize menghasilkan filter identik', () => { ... });

  // ✅ Integration — dipakai oleh SegmentManager
  it('filter mengurangi disk reads untuk key yang tidak ada', async () => { ... });
});
```

### 3.3 Menjalankan test incremental:
```bash
# Jalankan hanya test file baru dulu
node --import tsx/esm --test test/unit/nama-komponen.test.ts

# Lalu pastikan tidak merusak yang lain
npm run test:unit
npm run test:integration
npm test
```

---

## LANGKAH 4 — Integrasi dengan Komponen Lain

### 4.1 Cek apakah fitur perlu diexpose ke public API:
```typescript
// src/index.ts — jika perlu export
export { NamaKelas, type InterfaceBaru } from './nama-module/nama-file.js';
```

### 4.2 Cek apakah fitur perlu diintegrasikan ke OvnDB.open():
```typescript
// src/index.ts OvnDB class — jika ada opsi baru
export interface OvnOptions {
  // ... existing options ...
  /** [Penjelasan opsi baru] */
  namaOpsi?: TipeOpsi;
}
```

### 4.3 Update README.md jika API publik berubah:
- Tambah contoh penggunaan di bagian Quick Start atau fitur terkait
- Update tabel fitur jika ada

---

## LANGKAH 5 — Final Verification (TIDAK BOLEH SKIP)

```bash
# 1. TypeScript bersih
npx tsc --noEmit
echo "EXIT: $?"  # HARUS 0

# 2. Semua test pass
npm test
echo "EXIT: $?"  # HARUS 0

# 3. Jalankan contoh nyata (bukan hanya test)
npx tsx examples/basic-usage.ts
# Jika fitur baru punya example, jalankan juga:
npx tsx examples/[nama-example-baru].ts

# 4. Cek tidak ada debug log tertinggal
grep -rn "console\.log\|console\.error\|console\.warn" src/ --include="*.ts"
# Jika ada → hapus atau ganti dengan makeLogger
```

Jika salah satu dari langkah di atas gagal, **KEMBALI ke Langkah 2** dan fix.
Baru setelah semua pass, nyatakan fitur selesai.
