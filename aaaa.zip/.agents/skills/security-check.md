# Skill: security-check.md
# Digunakan saat: menyentuh kode storage, crypto, WAL, query filter, atau input dari user

---

## WAJIB DIBACA sebelum menyentuh file-file ini:
```
src/core/storage/   ← segment I/O, path construction
src/core/wal/       ← binary parsing, buffer allocation
src/core/index/     ← B+ Tree, page manager
src/utils/security.ts ← semua validator
src/crypto/         ← enkripsi/dekripsi
src/collection/     ← entry point semua input user
src/core/query/     ← filter dan aggregation parsing
```

---

## CHECKLIST KEAMANAN — Wajib dijalankan manual

Untuk setiap fungsi yang menerima parameter dari luar (user input, data dari disk, env var), tandai tiap boks ini secara eksplisit sebelum submit:

### A. Path Traversal
```
□ Apakah ada string yang digabung dengan path.join() / path.resolve()?
□ Apakah hasilnya divalidasi dengan assertPathInside() dari security.ts?
□ Apakah nama collection di-validate dengan validateCollectionName()?
□ Apakah ada path yang datang dari user yang belum di-sanitize?
```

Jika ada yang belum ditandai ✅ → tambahkan validasi atau jelaskan kenapa tidak perlu.

**Pola BENAR:**
```typescript
// ✅ validate nama collection sebelum join
validateCollectionName(name);  // throw jika invalid
const colDir = path.join(this.dataDir, name);

// ✅ validate backup destination
assertPathInside(this.dataDir, destPath);  // throw jika traversal
```

**Pola SALAH:**
```typescript
// ❌ langsung join tanpa validasi
const colDir = path.join(this.dataDir, userInput);

// ❌ validasi setelah join (sudah telat)
const colDir = path.join(this.dataDir, name);
if (!colDir.startsWith(this.dataDir)) throw ...;  // race condition pada symlink
```

---

### B. Prototype Pollution
```
□ Apakah ada kode yang set property pada object berdasarkan key dari user?
□ Apakah semua key di-check dengan isDangerousKey() sebelum dipakai?
□ Apakah ada Object.assign(), spread operator, atau dynamic key access?
```

**Pola BENAR:**
```typescript
// ✅ check sebelum set
function setNestedField(obj: Record<string, unknown>, path: string, value: unknown): void {
  const segments = path.split('.');
  for (const seg of segments) {
    if (isDangerousKey(seg)) throw new Error('[OvnDB] field path tidak diizinkan');
  }
  // ... set logic
}

// ✅ check key saat membaca dari user filter
for (const key of Object.keys(filter)) {
  if (isDangerousKey(key)) throw new Error('[OvnDB] filter key tidak diizinkan');
}
```

**Pola SALAH:**
```typescript
// ❌ set tanpa validasi key
obj[userKey] = value;

// ❌ Object.assign tanpa validasi
Object.assign(target, userProvidedObject);
```

---

### C. Buffer/Memory DoS
```
□ Apakah ada buffer yang ukurannya berdasarkan input user (atau dari disk)?
□ Apakah ukuran di-cap dengan konstanta dari constants.ts sebelum alokasi?
□ Apakah ada loop yang iterasinya bergantung pada user input?
□ Apakah $in/$nin array sudah di-check MAX_IN_ARRAY_SIZE?
□ Apakah pipeline stages sudah di-check MAX_PIPELINE_STAGES?
```

**Pola BENAR:**
```typescript
// ✅ validasi sebelum alokasi
if (dataLen > WAL_DATA_MAX_LEN) {
  throw new Error('[OvnDB] WAL entry data terlalu besar');
}
const buf = Buffer.allocUnsafe(dataLen);  // aman karena sudah di-cap

// ✅ validasi array size
if (Array.isArray(ops.$in) && ops.$in.length > MAX_IN_ARRAY_SIZE) {
  throw new Error('[OvnDB] $in array terlalu besar');
}
```

**Pola SALAH:**
```typescript
// ❌ allocate tanpa cap
const buf = Buffer.allocUnsafe(Number(dataLen));  // bisa OOM jika dataLen besar

// ❌ loop tanpa batas
for (let i = 0; i < userArray.length; i++) { ... }  // bisa infinite jika array besar
```

---

### D. ReDoS
```
□ Apakah ada RegExp yang pattern-nya datang dari user?
□ Apakah validateRegex() dari security.ts sudah dipanggil sebelum new RegExp()?
□ Apakah ada cached regex yang bisa dipakai ulang (daripada compile ulang tiap query)?
```

**Pola BENAR:**
```typescript
// ✅ validate sebelum compile
validateRegex(pattern);  // throw untuk nested quantifiers, panjang > 512 char
const regex = new RegExp(pattern, flags);

// ✅ cache regex untuk performa
private _regexCache = new Map<string, RegExp>();

private _getOrCompileRegex(pattern: string, flags: string): RegExp {
  const key = `${pattern}////${flags}`;
  if (this._regexCache.has(key)) return this._regexCache.get(key)!;
  validateRegex(pattern);
  const re = new RegExp(pattern, flags);
  this._regexCache.set(key, re);
  return re;
}
```

---

### E. Information Leakage
```
□ Apakah error message menyertakan nilai _id, path file, atau data sensitif?
□ Apakah log.error() hanya menyertakan metadata (bukan payload)?
□ Apakah backup destination di-redact dari log?
```

**Pola BENAR:**
```typescript
// ✅ error message tanpa nilai sensitif
throw new Error('[OvnDB] Duplicate _id');          // tidak ada nilai _id
throw new Error('[OvnDB] Record not found');        // tidak ada nilai _id
throw new Error('[OvnDB] Backup failed');           // tidak ada path

// ✅ log dengan redact
log.info('Backup complete', { col: this.colName }); // bukan { destPath }
```

**Pola SALAH:**
```typescript
// ❌ bocor nilai di error message
throw new Error(`[OvnDB] Duplicate _id: "${id}"`);
throw new Error(`[OvnDB] Record not found: "${id}"`);
throw new Error(`[OvnDB] Cannot backup to: ${destPath}`);
```

---

### F. File Permission
```
□ Apakah file baru dibuat dengan mode 0o600?
□ Apakah direktori baru dibuat dengan mode 0o700?
□ Apakah ada fs.writeFileSync / fsp.writeFile yang tidak set mode?
```

**Pola BENAR:**
```typescript
// ✅ explicit permission saat create
fs.writeFileSync(filePath, Buffer.alloc(0), { mode: 0o600 });
await fsp.mkdir(dirPath, { recursive: true, mode: 0o700 });
```

**Pola SALAH:**
```typescript
// ❌ tanpa explicit mode → default umask (biasanya 0o644/0o755)
fs.writeFileSync(filePath, Buffer.alloc(0));
await fsp.mkdir(dirPath, { recursive: true });
```

---

### G. Binary Parsing (WAL, Segment, B+Tree)
```
□ Apakah semua read dari binary buffer di-validate panjangnya sebelum dibaca?
□ Apakah ada readBigUInt64LE/readUInt32LE yang bisa baca di luar batas buffer?
□ Apakah CRC diverifikasi SEBELUM data di-parse (bukan setelah)?
□ Apakah ada BigInt yang dikonversi ke number tanpa pengecekan safe integer?
```

**Pola BENAR:**
```typescript
// ✅ check panjang sebelum parse
if (buf.length < REC_OVERHEAD) {
  throw new Error('[OvnDB] Buffer terlalu pendek untuk header record');
}
const status  = buf.readUInt8(0);
const txId    = buf.readBigUInt64LE(REC_STATUS_SIZE);
const dataLen = buf.readUInt32LE(REC_STATUS_SIZE + REC_TXID_SIZE);

// ✅ verifikasi CRC sebelum parse payload
const expectedCrc = readCrc(buf, buf.length - REC_CRC_SIZE);
const actualCrc   = crc32(buf.slice(0, buf.length - REC_CRC_SIZE));
if (expectedCrc !== actualCrc) throw new Error('[OvnDB] CRC mismatch');

// Baru parse payload setelah CRC valid
const payload = buf.slice(REC_PREFIX_SIZE, REC_PREFIX_SIZE + dataLen);
```

---

## KONSTANTA KEAMANAN — Referensi

Semua ada di `src/utils/security.ts`:

| Konstanta | Nilai | Tujuan |
|-----------|-------|--------|
| `MAX_DOCUMENT_BYTES` | 16 MB | Batas ukuran dokumen |
| `MAX_QUERY_DEPTH` | 12 | Batas nesting filter |
| `MAX_FILTER_KEYS` | 64 | Batas key per level filter |
| `MAX_REGEX_PATTERN_LEN` | 512 | Batas panjang regex pattern |
| `MAX_IN_ARRAY_SIZE` | 1,000 | Batas elemen $in/$nin |
| `MAX_PIPELINE_STAGES` | 32 | Batas stage aggregation |
| `MAX_COLLECTION_NAME` | 64 | Batas panjang nama collection |
| `MAX_FIELD_PATH_LEN` | 256 | Batas panjang field path |
| `MAX_ID_LEN` | 128 | Batas panjang _id |

Di `src/core/wal/wal.ts`:
| Konstanta | Nilai | Tujuan |
|-----------|-------|--------|
| `WAL_KEY_MAX_LEN` | 1,024 | Batas panjang WAL entry key |
| `WAL_DATA_MAX_LEN` | 32 MB | Batas ukuran WAL entry data |
| `WAL_MAX_SIZE_BYTES` | 256 MB | Batas ukuran file WAL |

---

## VALIDATOR FUNCTIONS — Mana yang dipakai di mana

```typescript
// Input: nama collection dari user
validateCollectionName(name)  → throw jika bukan [a-zA-Z0-9_-]{1,64}

// Input: field path (dot-notation) dari user
validateFieldPath(path)       → throw jika mengandung segmen berbahaya

// Input: query filter dari user
validateQueryFilter(filter)   → throw jika terlalu dalam/besar/berbahaya

// Input: update spec dari user
validateUpdateSpec(spec)      → throw jika operator tidak dikenal

// Input: dokumen yang akan disimpan
validateDocumentSize(buf)     → throw jika > 16 MB
validateDocumentKeys(doc)     → throw jika ada key __proto__ dll
validateDocumentId(id)        → throw jika id tidak valid

// Input: pattern regex dari user
validateRegex(pattern)        → throw jika ReDoS pattern atau terlalu panjang

// Input: path untuk backup/restore
assertPathInside(base, target) → throw jika target di luar base

// Check key individual
isDangerousKey(key)           → true jika __proto__, constructor, prototype, dll
```

---

## PROSEDUR AUDIT KEAMANAN — Jalankan setelah setiap perubahan besar

```bash
# 1. Pastikan security test masih pass
npm run test:security

# 2. Cari pola berbahaya yang mungkin terlewat
grep -rn "new RegExp\|RegExp(" src/ --include="*.ts" | grep -v "validateRegex\|security.ts"
# → Setiap baris yang muncul HARUS ada validateRegex() sebelumnya

grep -rn "Buffer.alloc\|Buffer.allocUnsafe" src/ --include="*.ts"
# → Setiap alokasi HARUS ada validasi ukuran sebelumnya

grep -rn "path\.join\|path\.resolve" src/ --include="*.ts"
# → Setiap path construction dengan user input HARUS ada validasi

grep -rn "__proto__\|constructor\[" src/ --include="*.ts"
# → TIDAK BOLEH ADA yang tidak di dalam security.ts

# 3. Verifikasi file permissions di test
grep -rn "0o600\|0o700" src/core/storage/ src/core/wal/ src/core/index/ --include="*.ts"
# → Setiap file create HARUS ada permission 0o600
```
