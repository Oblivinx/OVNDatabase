# Skill: run-and-verify.md
# Digunakan saat: task selesai dan perlu verifikasi akhir sebelum lapor "done"
# Juga digunakan saat: perlu verifikasi bahwa existing code masih berjalan

---

## PRINSIP: "WORKS ON MY MACHINE" TIDAK CUKUP

Kode dianggap selesai hanya jika:
1. TypeScript compile tanpa error
2. Semua test pass
3. Example bisa dijalankan sampai selesai tanpa error
4. Output example masuk akal (bukan gibberish atau error yang di-swallow)

---

## URUTAN VERIFIKASI WAJIB

### Step 1 — TypeScript Clean
```bash
npx tsc --noEmit 2>&1
# Expected output: kosong (tidak ada output = tidak ada error)
# Jika ada output → FIX DULU
```

### Step 2 — Unit Tests
```bash
npm run test:unit 2>&1
# Expected: semua ✓, tidak ada ✗, tidak ada skip mencurigakan
# Exit code harus 0
```

### Step 3 — Integration Tests
```bash
npm run test:integration 2>&1
# Expected: semua ✓
# Perhatikan test yang melibatkan disk I/O — pastikan tmpdir di-cleanup
```

### Step 4 — Security Tests
```bash
npm run test:security 2>&1
# Expected: semua ✓, 70+ assertions pass
# Jika ada yang fail → ini CRITICAL, tidak boleh bypass
```

### Step 5 — Full Suite (Gate terakhir)
```bash
npm test 2>&1
# Expected: semua pass, exit code 0

# Capture dan check exit code
npm test
RESULT=$?
echo "=== FULL TEST RESULT: $RESULT ==="
if [ $RESULT -ne 0 ]; then
  echo "❌ GAGAL — task belum selesai"
else
  echo "✅ PASS — test suite clean"
fi
```

### Step 6 — Run Examples (Smoke Test)
```bash
# Basic usage — operasi fundamental harus jalan
OVNDB_LOG=info npx tsx examples/basic-usage.ts 2>&1
echo "basic-usage exit: $?"

# Complex CRUD — operasi lanjutan
OVNDB_LOG=info npx tsx examples/complex-crud.ts 2>&1
echo "complex-crud exit: $?"

# v3 showcase — fitur v3.x harus jalan
OVNDB_LOG=info npx tsx examples/v3-showcase.ts 2>&1
echo "v3-showcase exit: $?"
```

**Yang harus diperhatikan dari output examples:**
```
✅ Output terakhir adalah "sukses" atau data yang masuk akal
✅ Tidak ada unhandled rejection atau uncaught exception
✅ Process exit normal (tidak hang)
✅ Tidak ada "[OvnDB] ERROR" atau "[OvnDB] WARN" yang tidak diharapkan
```

---

## MENJALANKAN EXAMPLE BARU

Jika task membuat fitur baru yang punya example:

```typescript
// Template: examples/nama-fitur.ts
// ============================================================
//  OvnDB — Example: [Nama Fitur]
//  Mendemonstrasikan:
//   1. [skenario 1]
//   2. [skenario 2]
// ============================================================

import { OvnDB } from '../src/index.js';
import os   from 'node:os';
import path from 'node:path';
import fs   from 'node:fs';
import fsp  from 'node:fs/promises';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ovndb-example-'));
console.log('📂 Data dir:', dir);

try {
  const db = await OvnDB.open(dir);

  // === Demonstrasi fitur ===

  console.log('✅ Semua demonstrasi berhasil');
} catch (err) {
  console.error('❌ Example gagal:', err);
  process.exit(1);  // WAJIB: exit dengan kode error
} finally {
  await fsp.rm(dir, { recursive: true, force: true });
  console.log('🧹 Cleanup selesai');
}
```

```bash
# Jalankan example baru
OVNDB_LOG=info npx tsx examples/nama-fitur.ts 2>&1
echo "Exit code: $?"  # HARUS 0
```

---

## QUICK BENCHMARK (Opsional tapi Direkomendasikan)

Jalankan ini setelah mengubah storage layer atau query engine untuk memastikan tidak ada regresi performa:

```bash
# Benchmark dengan 10K records (cepat, ~30 detik)
npm run bench 2>&1 | tail -30

# Benchmark dengan 50K records (lebih representatif)
npm run bench:50k 2>&1 | tail -30
```

**Baseline performa yang diharapkan (dari README):**
```
insertOne:              ~20,000 ops/s
findOne (cache hit):    ~35,000 ops/s
updateOne:              ~15,000 ops/s
deleteOne:              ~22,000 ops/s
Full scan (100K docs):  ~120 ms
aggregate:              ~90 ms
```

Jika performa turun lebih dari 20% → **LAPOR ke user** sebelum submit.

---

## CHECKLIST FINAL — Copy-paste dan isi sebelum lapor "done"

```
CHECKLIST VERIFIKASI AKHIR
==========================

Task: [Deskripsi task]
Tanggal: [Tanggal]

TypeScript:
[ ] npx tsc --noEmit  → EXIT 0

Testing:
[ ] npm run test:unit        → X pass, 0 fail
[ ] npm run test:integration → X pass, 0 fail
[ ] npm run test:security    → X pass, 0 fail
[ ] npm test (full)          → EXIT 0

Examples:
[ ] basic-usage.ts           → EXIT 0
[ ] complex-crud.ts          → EXIT 0
[ ] v3-showcase.ts           → EXIT 0
[ ] [nama-example-baru].ts   → EXIT 0 (jika ada)

Code Quality:
[ ] Tidak ada console.log debug yang tertinggal
[ ] Tidak ada TODO/FIXME yang belum diselesaikan
[ ] Tidak ada @ts-ignore
[ ] Semua konstanta baru ada di types/constants.ts
[ ] Semua type baru ada di types/index.ts
[ ] Semua validasi baru ada di utils/security.ts
[ ] Import path semua pakai .js extension

Breaking Changes:
[ ] Tidak ada (atau sudah di-lapor ke user)

Performa:
[ ] Tidak ada regresi performa signifikan (atau sudah di-lapor)

STATUS: ✅ SELESAI / ❌ BELUM SELESAI (sebutkan apa yang masih kurang)
```

---

## TROUBLESHOOTING — Example gagal tapi test pass

Ini berarti ada yang tidak dicakup test. Langkah:

```bash
# 1. Jalankan example dengan log verbose
OVNDB_LOG=debug npx tsx examples/nama-example.ts 2>&1 | head -100

# 2. Cari baris error
OVNDB_LOG=debug npx tsx examples/nama-example.ts 2>&1 | grep -E "ERROR|WARN|Error:|throw"

# 3. Jika process hang, tambah timeout
timeout 30 OVNDB_LOG=debug npx tsx examples/nama-example.ts 2>&1
echo "Exit: $?"
# Exit 124 = timeout → ada yang hang (event loop tidak kosong, file tidak di-close, dll)
```

**Penyebab umum example hang:**
```typescript
// 1. Lupa await db.close()
// → Tambahkan always di finally block

// 2. File descriptor tidak di-close
// → Cek setiap fs.openSync → harus ada fs.closeSync di finally

// 3. Timer tidak di-clear
// → Cek setInterval/setTimeout → harus ada clearInterval/clearTimeout di cleanup

// 4. Event listener tidak di-remove
// → Cek .on() atau .watch() → harus ada .close() atau .removeListener()
```
