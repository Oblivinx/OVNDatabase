# CLAUDE.md — Law of OvnDB

> Ini adalah file instruksi untuk Claude CLI (claude-code).
> Semua aturan di sini bersifat **WAJIB** dan **tidak bisa dinegosiasi**.
> Tidak ada pengecualian tanpa explicit override dari user di sesi yang sama.

---

## ⛔ LARANGAN ABSOLUT — LANGGAR = STOP TOTAL

Claude **WAJIB BERHENTI** dan **LAPOR KE USER** jika hampir melakukan salah satu dari ini:

```
1. Menjalankan `rm -rf` di luar direktori /tmp atau direktori test sementara
2. Menulis file ke luar project root tanpa izin eksplisit user
3. Meng-install package baru (npm/pip) tanpa izin eksplisit user
4. Mengubah package.json, tsconfig.json, atau tsconfig.build.json tanpa izin eksplisit
5. Menghapus atau overwrite file test yang sudah ada
6. Men-commit atau push ke git tanpa perintah eksplisit dari user
7. Membuat file dengan nama yang sudah ada tanpa membaca isinya dulu
8. Skip langkah verifikasi dengan alasan apapun
9. Menyatakan "selesai" sebelum semua test pass
10. Membuat placeholder / TODO / stub yang tidak berfungsi dan tidak memberitahu user
```

---

## 🔁 WORKFLOW WAJIB — Urutan ini tidak boleh diubah

Untuk setiap task coding yang diberikan user, Claude WAJIB menjalankan urutan ini:

### Fase 1: READ BEFORE WRITE (tidak boleh skip)
```
[R1] Baca semua file yang relevan dengan task — SELURUH file, bukan sebagian
[R2] Baca types/index.ts dan types/constants.ts untuk memahami kontrak
[R3] Jika ada file test terkait, baca juga — test mendefinisikan kontrak behavior
[R4] Cari apakah fungsi/class yang mirip sudah ada — jangan duplikasi
[R5] REPORT ke user: "Saya akan mengubah file X, Y, Z. Apakah ada yang perlu diperhatikan?"
     → Hanya skip R5 jika task sangat kecil (1 baris, typo fix, dll)
```

### Fase 2: IMPLEMENT (satu file dalam satu waktu)
```
[I1] Tulis implementasi LENGKAP — tidak ada TODO, tidak ada stub kosong
[I2] Setiap exported function/class WAJIB punya JSDoc minimal 1 baris
[I3] Setiap `catch (e)` WAJIB punya handling yang spesifik — tidak boleh `catch (e) {}`
[I4] Setiap angka magic WAJIB jadi konstanta bernama di types/constants.ts
[I5] Import path WAJIB pakai extension .js (NodeNext moduleResolution)
[I6] Setelah setiap file ditulis, jalankan: npx tsc --noEmit 2>&1 | head -30
     → Jika ada error TypeScript, FIX DULU sebelum lanjut ke file berikutnya
```

### Fase 3: TEST (tidak boleh skip satu langkah pun)
```
[T1] Jalankan test yang spesifik untuk fitur yang diubah
[T2] Jalankan full test suite: npm test
[T3] Capture SELURUH output — jangan potong
[T4] Jika ada test yang FAIL:
     → Baca error message lengkap
     → Fix bug (kembali ke Fase 2)
     → Ulangi Fase 3 dari awal
     → Maksimal 3 iterasi — jika masih fail, LAPOR ke user dengan detail lengkap
[T5] Jika ada test yang SKIP tanpa alasan jelas, LAPOR ke user
```

### Fase 4: VERIFY & REPORT
```
[V1] Tampilkan ringkasan: file apa yang diubah, baris apa yang ditambah/dihapus
[V2] Tampilkan output npm test terakhir (minimal 10 baris terakhir)
[V3] Jika ada perilaku edge case yang belum dicakup test, sebutkan eksplisit
[V4] Jika ada breaking change ke API publik, sebutkan dengan JELAS dan KAPITAL
```

---

## 📁 STRUKTUR FILE — Aturan penempatan wajib

```
src/
├── collection/         ← Collection, CollectionV2 — entry point user
├── core/
│   ├── cache/          ← LRU dan cache internal
│   ├── index/          ← B+ Tree, secondary index
│   ├── query/          ← filter, planner, aggregation
│   ├── storage/        ← storage engine, segment, page manager
│   ├── transaction/    ← MVCC, transaction coordinator
│   └── wal/            ← Write-Ahead Log
├── crypto/             ← enkripsi layer
├── migration/          ← migration runner
├── schema/             ← schema validator
├── ttl/                ← TTL index worker
├── types/
│   ├── constants.ts    ← SEMUA konstanta angka/string di sini
│   └── index.ts        ← SEMUA type/interface di sini
└── utils/
    ├── crc32.ts
    ├── file-lock.ts
    ├── id-generator.ts
    ├── logger.ts
    └── security.ts     ← SEMUA validasi keamanan di sini
```

### Aturan penempatan:
- Konstanta angka/string baru → `types/constants.ts` (bukan inline di kode)
- Type/interface baru → `types/index.ts` (bukan inline di kode)
- Validasi input baru → `utils/security.ts` (bukan tersebar di mana-mana)
- File baru di `src/` → **WAJIB** diexport dari `src/index.ts` jika bagian dari public API
- File test baru → `test/unit/` (murni logika) atau `test/integration/` (butuh disk/tmpdir)

---

## 🔷 TYPESCRIPT — Aturan ketat

### Dilarang keras:
```typescript
// ❌ any eksplisit tanpa komentar justifikasi
const x: any = something;

// ❌ non-null assertion tanpa guard sebelumnya
const val = obj.prop!;

// ❌ type cast tanpa validasi
const typed = value as SpecificType;

// ❌ catch tanpa handling
try { ... } catch (e) {}

// ❌ ignore TypeScript error dengan @ts-ignore
// @ts-ignore

// ❌ import tanpa extension .js
import { foo } from './utils/bar';  // SALAH
import { foo } from './utils/bar.js';  // BENAR

// ❌ magic number inline
if (buffer.length > 16777216) { ... }  // SALAH
if (buffer.length > MAX_DOCUMENT_BYTES) { ... }  // BENAR
```

### Wajib:
```typescript
// ✅ any harus ada justifikasi
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type TxOp = InsertOp<any> | UpdateOp<any>;  // union memerlukan any untuk generic erasure

// ✅ null check sebelum assertion
if (this.fd === null) throw new Error('[OvnDB] WAL not open');
const read = fs.readSync(this.fd, ...);  // sekarang aman

// ✅ type guard eksplisit
function isOvnDocument(val: unknown): val is OvnDocument {
  return typeof val === 'object' && val !== null && '_id' in val;
}

// ✅ readonly untuk data yang tidak boleh diubah
private readonly dirPath: string;
```

---

## 🧪 TESTING — Kontrak yang tidak boleh dilanggar

### Format test file wajib:
```typescript
// ============================================================
//  OvnDB — [Unit|Integration|Security] Tests: [Nama Komponen]
//  Cakupan:
//   1. [skenario 1]
//   2. [skenario 2]
// ============================================================

import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
```

### Aturan setiap test case:
1. **Satu test = satu assertion utama** — jangan gabungkan 5 hal tidak berkaitan
2. **Nama test harus deskriptif** — bukan `it('works')` tapi `it('menolak dokumen > 16 MB')`
3. **Integration test WAJIB** pakai `tmpdir()` → cleanup di `after()`/`finally`
4. **Tidak boleh** hardcode path absolut di test
5. **Tidak boleh** bergantung pada urutan eksekusi test lain

### Template integration test:
```typescript
import os from 'node:os';
import path from 'node:path';
import fsp from 'node:fs/promises';

function tmpDir(): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'ovndb-test-'));
}

async function rmDir(p: string): Promise<void> {
  await fsp.rm(p, { recursive: true, force: true });
}

describe('NamaKomponen', async () => {
  let dir: string;
  let db: OvnDB;

  before(async () => {
    dir = tmpDir();
    db = await OvnDB.open(dir, { fileLock: false });
  });

  after(async () => {
    await db.close();
    await rmDir(dir);
  });

  it('deskripsi test yang jelas', async () => {
    // arrange
    // act
    // assert
  });
});
```

### Menjalankan test — URUTAN WAJIB:
```bash
# 1. Type check dulu
npx tsc --noEmit

# 2. Unit test (cepat, tidak butuh disk)
npm run test:unit

# 3. Integration test
npm run test:integration

# 4. Security test
npm run test:security

# 5. Full suite (CI gate)
npm test

# Untuk fitur baru, jalankan juga example:
npx tsx examples/basic-usage.ts
```

---

## 🔒 SECURITY — Aturan yang tidak pernah boleh dilanggar

Setiap kali menulis kode yang menerima input dari luar (parameter fungsi, data dari disk, env var), Claude WAJIB tanya diri sendiri dan jawab secara eksplisit dalam komentar kode:

```
Q: Apakah input ini bisa berisi path traversal? (../../../etc)
Q: Apakah input ini bisa menyebabkan prototype pollution? (__proto__, constructor)
Q: Apakah input ini bisa menyebabkan ReDoS? (regex dari user)
Q: Apakah input ini bisa menyebabkan OOM? (ukuran tidak dibatasi)
Q: Apakah error message membocorkan informasi sensitif?
```

Setiap validator baru WAJIB ditambahkan ke `src/utils/security.ts` dan di-reuse — jangan buat validasi inline.

---

## 📝 KOMENTAR — Standar yang tidak boleh dilanggar

### Header setiap file baru:
```typescript
// ============================================================
//  OvnDB [versi] — [Nama Komponen]
//
//  [Penjelasan satu paragraf tentang tanggung jawab komponen ini]
//
//  DESAIN:
//  - [Keputusan desain penting 1]
//  - [Keputusan desain penting 2]
//
//  LIMITASI:
//  - [Batasan yang disengaja, jika ada]
// ============================================================
```

### Komentar inline:
- **WAJIB** pada logika yang tidak intuitif
- **WAJIB** pada setiap workaround/hack dengan penjelasan kenapa
- **WAJIB** pada setiap angka yang tidak dari konstanta (jika ada alasan khusus)
- **DILARANG** pada kode yang self-explanatory (`// increment i` di `i++`)

---

## 🚨 PROSEDUR DARURAT — Ketika sesuatu tidak berjalan

Jika setelah 3 iterasi fix test masih fail, Claude WAJIB:

```
1. STOP — jangan terus mencoba fix yang sama
2. LAPOR ke user dengan format:
   ────────────────────────────────────────
   🔴 STUCK setelah 3 iterasi
   
   FILE YANG DIUBAH:
   - src/xxx.ts (baris N-M)
   
   TEST YANG FAIL:
   [paste output error lengkap]
   
   HIPOTESIS PENYEBAB:
   1. [hipotesis 1]
   2. [hipotesis 2]
   
   OPSI SOLUSI:
   A. [opsi A — trade-off]
   B. [opsi B — trade-off]
   
   Menunggu keputusan dari Anda.
   ────────────────────────────────────────

3. TUNGGU respons user — jangan ambil keputusan unilateral
```

---

## 📋 SKILL FILES — Kapan harus dibaca

Claude WAJIB membaca skill file yang relevan sebelum memulai task:

| Task | Skill file yang wajib dibaca |
|------|------------------------------|
| Implementasi fitur baru | `.claude/skills/new-feature.md` |
| Fix bug / debugging | `.claude/skills/debug-fix.md` |
| Tulis/update test | `.claude/skills/testing-mandatory.md` |
| Kode yang menyentuh storage/crypto/WAL | `.claude/skills/security-check.md` |
| TypeScript refactor / type changes | `.claude/skills/typescript-strict.md` |

---

## ✅ CHECKLIST SEBELUM LAPOR "SELESAI"

Claude WAJIB mental-check semua poin ini sebelum menyatakan task selesai:

- [ ] `npx tsc --noEmit` → 0 error
- [ ] `npm run test:unit` → semua pass
- [ ] `npm run test:integration` → semua pass
- [ ] `npm run test:security` → semua pass
- [ ] `npm test` → semua pass, tidak ada skip mencurigakan
- [ ] Tidak ada `console.log` debug yang tertinggal
- [ ] Tidak ada `TODO` atau `FIXME` yang belum diselesaikan dalam task ini
- [ ] Setiap konstanta baru ada di `types/constants.ts`
- [ ] Setiap type baru ada di `types/index.ts`
- [ ] Setiap validasi baru ada di `utils/security.ts`
- [ ] Import path semua pakai `.js` extension
- [ ] File baru sudah diexport dari `src/index.ts` jika perlu

Jika salah satu tidak terpenuhi, **task belum selesai**.
